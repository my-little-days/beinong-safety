北農安全資訊平台完整更新包
包含15張宣導圖卡與1張App圖示。
GitHub上傳：將ZIP解壓縮，將裡面的index.html、manifest.webmanifest、icon-192.png、icon-512.png與images資料夾上傳到專案根目錄。請勿直接上傳ZIP作為網站檔案。
